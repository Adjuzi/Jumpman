package se.liu.adaan690.davas593.tddd78.jumpman;

public interface Collidable {
    void checkCollisions(Player player);

    double getXPos();
    double getYPos();
    int getWidth();
    int getHeight();
}
