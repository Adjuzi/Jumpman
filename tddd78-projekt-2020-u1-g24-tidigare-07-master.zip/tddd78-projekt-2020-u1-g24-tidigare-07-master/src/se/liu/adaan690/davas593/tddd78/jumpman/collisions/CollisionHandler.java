package se.liu.adaan690.davas593.tddd78.jumpman.collisions;

import se.liu.adaan690.davas593.tddd78.jumpman.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.Player;

public abstract class CollisionHandler {
    public Collidable collidable;

    public CollisionHandler(Collidable collidable) {
        this.collidable = collidable;
    }

    public abstract void checkCollision(Player player);
}
