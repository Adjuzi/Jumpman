package se.liu.adaan690.davas593.tddd78.jumpman.levels;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;

import java.awt.*;

public class PowerUp {
    private double xPos;
    private double yPos;

    private int width = JumpmanPanel.STANDARDUNIT/2;
    private int height = JumpmanPanel.STANDARDUNIT/2;
    private Color color = Color.CYAN;

    public PowerUp(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

    public void setXPos(double xPos) {
        this.xPos = xPos;
    }

    public void setYPos(double yPos) {
        this.yPos = yPos;
    }

    public double getXPos() {
        return xPos;
    }

    public double getYPos() {
        return yPos;
    }

    public int getIntXPos() {
        return (int) Math.round(xPos);
    }

    public int getIntYPos() {
        return (int) Math.round(yPos);
    }

    public Color getColor() {
        return color;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());
    }
}
