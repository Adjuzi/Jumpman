package se.liu.adaan690.davas593.tddd78.jumpman.collisions;

import se.liu.adaan690.davas593.tddd78.jumpman.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.Player;

public class TopCollisionHandler extends CollisionHandler {


    public TopCollisionHandler(Collidable collidable) {
        super(collidable);
    }

    @Override
    public void checkCollision(Player player) {
        if(player.getYPos()+player.getHeight() >= collidable.getYPos()
                && player.getPreviousYPos()+player.getHeight() < collidable.getYPos()) {
            if (player.getXPos() + player.getWidth() > collidable.getXPos() && player.getXPos() <= collidable.getXPos() + collidable.getWidth()) {
                player.setYPos(collidable.getYPos() - player.getHeight() - 0.0001);
                player.setVelY(0);
                player.setInAir(false);
            }
        }
    }
}
