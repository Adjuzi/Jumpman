package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Ladder;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

public class LadderCollisionHandler extends OverlappingCollisionHandler
{
    public LadderCollisionHandler(final Ladder ladder) {
	super(ladder);
    }

    @Override public void handleCollision(final MovableObject movable) {
	movable.setAffectedByGravity(false);
	movable.setInAir(false);
    }
}
