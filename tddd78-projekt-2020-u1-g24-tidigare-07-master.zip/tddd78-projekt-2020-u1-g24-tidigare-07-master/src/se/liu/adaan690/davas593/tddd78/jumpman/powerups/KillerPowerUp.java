package se.liu.adaan690.davas593.tddd78.jumpman.powerups;

import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.CollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.EnemyKillCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player.Enemy;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class KillerPowerUp extends PowerUp
{
    public KillerPowerUp(final Level level) {
	super(level, Color.CYAN);
    }

    @Override public void activate() {
        List<Enemy> enemies = level.getEnemies();

        for (Enemy enemy : enemies) {
            enemy.setWeak(true);

            List<CollisionHandler> powerUpCollisionHandlers = new ArrayList<>();
            powerUpCollisionHandlers.add(new EnemyKillCollisionHandler(enemy, CollisionSide.TOP));
            powerUpCollisionHandlers.add(new EnemyKillCollisionHandler(enemy, CollisionSide.BOTTOM));
            powerUpCollisionHandlers.add(new EnemyKillCollisionHandler(enemy, CollisionSide.LEFT));
            powerUpCollisionHandlers.add(new EnemyKillCollisionHandler(enemy, CollisionSide.RIGHT));
            enemy.addTemporaryCollisionHandlers(powerUpCollisionHandlers);
        }

        super.activate();
    }

    @Override public void deactivate() {
        List<Enemy> enemies = level.getEnemies();

        for (Enemy enemy : enemies) {
            enemy.setWeak(false);
            enemy.resetCollisionHandlers();
        }
    }
}
