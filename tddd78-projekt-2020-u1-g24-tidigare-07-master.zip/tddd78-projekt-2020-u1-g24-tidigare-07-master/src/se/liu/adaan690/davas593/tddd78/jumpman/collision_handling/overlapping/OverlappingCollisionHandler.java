package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping;

import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.CollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

public abstract class OverlappingCollisionHandler extends CollisionHandler
{

    protected OverlappingCollisionHandler(Collidable collidable) {
	super(collidable);
    }

    @Override public boolean detectCollision(MovableObject movable) {
	return (movable.getXPos() <= collidable.getXPos() + collidable.getWidth() &&
		movable.getXPos() + movable.getWidth() >= collidable.getXPos() &&
		movable.getYPos() <= collidable.getYPos() + collidable.getHeight() &&
		movable.getYPos() + movable.getHeight() >= collidable.getYPos());
    }
}
