package se.liu.adaan690.davas593.tddd78.jumpman;

import java.awt.*;

public class Ladder {
    private int xPos;
    private int yPos;
    private int height;
    private int width;
    private Color color = Color.red;

    public Ladder(int xPos, int yPos, int height, int width) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.height = height;
        this.width = width;
    }

    public int getXPos() {
        return xPos;
    }

    public int getYPos() {
        return yPos;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public boolean checkClimbing(Player player) {
        if(player.getXPos()+JumpmanPanel.STANDARDUNIT > xPos && player.getXPos() < xPos +width){
            return player.getYPos() < yPos + height && player.getYPos() > yPos - JumpmanPanel.STANDARDUNIT;
        }

        return false;
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(xPos, yPos, width, height);
    }
}
