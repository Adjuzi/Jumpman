package se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.spawn_points;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player.Enemy;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.util.Timer;
import java.util.TimerTask;

public class SpawnPoint
{
    private int xPos;
    private int yPos;
    private Direction direction;

    private Level level;

    private Timer spawnTimer;
    private SpawnEnemyTask spawnEnemyTask;
    private long startDelay;
    private long spawnPeriod;

    public SpawnPoint(int xPos, int yPos, Direction direction, Level level, long startDelay, long spawnPeriod) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.direction = direction;
        this.level = level;
        this.startDelay = startDelay;
        this.spawnPeriod = spawnPeriod;
	spawnTimer = new Timer();
	spawnEnemyTask = new SpawnEnemyTask();
    }

    public void activate() {
	spawnTimer.scheduleAtFixedRate(spawnEnemyTask, startDelay, spawnPeriod);
    }
    public void deactivate() {
        spawnTimer.cancel();
    }

    private class SpawnEnemyTask extends TimerTask {
	@Override public void run() {
	    Enemy enemy = Enemy.createBasicEnemy(level, xPos, yPos);
	    enemy.setVelX(enemy.getVelX() * direction.value);
	    level.addEnemy(enemy);
	}
    }

    public enum Direction {
        RIGHT(1),
	LEFT(-1),
	;

        public final int value;

	private Direction(final int i) {
	    value = i;
	}
    }
}
