package se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.CollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.DeadlyCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.EnemyKillCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Enemy extends NonPlayerMovableObject implements Collidable
{
    private static final double ENEMY_BASE_SPEED = STANDARD_SPEED * 0.6;

    private List<CollisionHandler> collisionHandlers = new ArrayList<>();
    private List<CollisionHandler> savedCollisionHandlers = null;

    private boolean weak = false;
    private int weakCounter = 0;

    public Enemy(final Level level, int xPos, int yPos) {
        super(level, xPos, yPos, Color.PINK);
        setVelX(ENEMY_BASE_SPEED);
    }

    public void draw(Graphics g) {
        if (weak && weakCounter < BLINK_PERIOD) {
            weakCounter++;
        } else {
            weakCounter = 0;
        }

        if (weakCounter <= BLINK_PERIOD / 2) {
            g.setColor(getColor());
        } else {
            g.setColor(Color.WHITE);
        }
        g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());
    }

    @Override public void checkCollisions(final MovableObject movable) {
        for (CollisionHandler collisionHandler : collisionHandlers) {
            if (collisionHandler.detectCollision(movable)) {
                collisionHandler.handleCollision(movable);
            }
        }
    }

    @Override public void move(long deltaTime) {
        super.move(deltaTime);
        velY += level.getGravity() * weight * ((double) deltaTime / JumpmanPanel.NANO_SECOND);
    }

    public void addCollisionHandler(CollisionHandler collisionHandler) {
        collisionHandlers.add(collisionHandler);
    }

    public void addTemporaryCollisionHandlers(List<CollisionHandler> collisionHandlers) {
        savedCollisionHandlers = new ArrayList<>(this.collisionHandlers);
        this.collisionHandlers = collisionHandlers;
    }

    public void resetCollisionHandlers() {
        if (savedCollisionHandlers != null) {
            collisionHandlers = savedCollisionHandlers;
            savedCollisionHandlers = null;
        }
    }

    public void setWeak(final boolean weak) {
        this.weak = weak;
    }

    public static Enemy createBasicEnemy(final Level level, int xPos, int yPos) {
        Enemy enemy = new Enemy(level, xPos, yPos);
        enemy.addCollisionHandler(new DeadlyCollisionHandler(enemy, CollisionSide.BOTTOM));
        enemy.addCollisionHandler(new DeadlyCollisionHandler(enemy, CollisionSide.RIGHT));
        enemy.addCollisionHandler(new DeadlyCollisionHandler(enemy, CollisionSide.LEFT));
        enemy.addCollisionHandler(new EnemyKillCollisionHandler(enemy, CollisionSide.TOP));

        return enemy;
    }
}
