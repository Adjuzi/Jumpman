package se.liu.adaan690.davas593.tddd78.jumpman.game_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

public interface Collidable {
    void checkCollisions(MovableObject movable);

    double getXPos();
    double getYPos();
    int getWidth();
    int getHeight();
}
