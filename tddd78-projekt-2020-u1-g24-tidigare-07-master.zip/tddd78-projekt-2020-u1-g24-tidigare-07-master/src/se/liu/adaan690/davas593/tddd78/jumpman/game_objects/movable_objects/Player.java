package se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;

public class Player extends MovableObject
{
    private static final double JUMP_FORCE = -300;
    private static final int PLAYER_BASE_STRENGTH = 40;

    private boolean jumping = false;
    private boolean climbing = false;

    private int strength = PLAYER_BASE_STRENGTH;

    public Player(final Level level, int xPos, int yPos) {
        super(level, xPos, yPos, Color.GREEN);
    }

    @Override public void handleSideCollision(CollisionSide collisionSide) {
        switch (collisionSide){
            case TOP:
                inAir = false;
                setVelY(0);
                break;
            case BOTTOM:
                setVelY(0);
                break;
            case RIGHT:
            case LEFT:
                setVelX(0);
                break;
        }
    }

    public void setJumping(final boolean jumping) {
        this.jumping = jumping;
    }

    public void jump() {
        if (!inAir && !jumping) {
            setVelY(JUMP_FORCE);
            jumping = true;
        }
    }

    public boolean isClimbing() {
        return climbing;
    }

    public void setClimbing(final boolean climbing) {
        this.climbing = climbing;
    }

    public int getStrength() {
        return strength;
    }

    public void move(long deltaTime){
        super.move(deltaTime);
        if (!climbing) {
            velY += level.getGravity() * weight * ((double) deltaTime / JumpmanPanel.NANO_SECOND);
        }
    }

    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());
    }
}
