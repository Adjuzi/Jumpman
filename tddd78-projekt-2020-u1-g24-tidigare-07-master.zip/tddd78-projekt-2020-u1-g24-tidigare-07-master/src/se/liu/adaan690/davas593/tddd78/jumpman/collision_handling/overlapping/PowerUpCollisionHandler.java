package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.PowerUpObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.Player;

public class PowerUpCollisionHandler extends OverlappingCollisionHandler
{

    public PowerUpCollisionHandler(final PowerUpObject powerUpObject) {
	super(powerUpObject);
    }

    @Override public void handleCollision(final MovableObject movable) {
	PowerUpObject powerUpObject = (PowerUpObject) collidable;
	/*
	Special handling especially for Player class, why an instanceof is needed in this case.
	MovableObjects are handled generally otherwise.
	 */
	//noinspection InstanceofConcreteClass
	if (movable instanceof Player) {
	    powerUpObject.activatePowerUp();
	}
    }
}
