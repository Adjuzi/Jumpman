package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.WinFlag;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.Player;

public class WinFlagCollisionHandler extends OverlappingCollisionHandler
{
    public WinFlagCollisionHandler(final WinFlag winFlag) {
	super(winFlag);
    }

    @Override public void handleCollision(final MovableObject movable) {
	WinFlag winFlag = (WinFlag) collidable;
	/*
	Special handling especially for Player class, why an instanceof is needed in this case.
	MovableObjects are handled generally otherwise.
	 */
	//noinspection InstanceofConcreteClass
	if (movable instanceof Player) {
	    winFlag.setReached(true);
	}
    }
}
