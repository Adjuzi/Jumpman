package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side;

public enum CollisionSide
{
    TOP(), RIGHT(), BOTTOM(), LEFT()
}
