package se.liu.adaan690.davas593.tddd78.jumpman.powerups;

import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public abstract class PowerUp
{
    private static final int POWER_UP_DURATION = 5000;
    protected final Level level;
    protected final Color color;
    protected int duration = POWER_UP_DURATION;
    protected Timer activationTimer;
    protected TimerTask deactivationTask = null;

    protected PowerUp(final Level level, final Color color) {
        this.level = level;
        this.color = color;
        activationTimer = new Timer();
    }

    public Color getColor() {
    	return color;
        }

    public void activate() {
        level.activatePowerUp(this);
        deactivationTask = new DeactivationTask();
        activationTimer.schedule(deactivationTask, duration);
    }
    public void deactivate() {
        level.deactivatePowerUp(this);
    }

    public void cancelPowerUp() {
        deactivationTask.cancel();
        deactivate();
    }

    protected class DeactivationTask extends TimerTask {
        @Override public void run() {
            deactivate();
        }
    }
}
