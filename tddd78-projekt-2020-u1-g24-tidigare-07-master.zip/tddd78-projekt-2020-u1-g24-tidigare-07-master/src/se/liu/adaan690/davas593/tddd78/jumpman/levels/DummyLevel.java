package se.liu.adaan690.davas593.tddd78.jumpman.levels;

import se.liu.adaan690.davas593.tddd78.jumpman.*;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.LeftCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.RightCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.TopCollisionHandler;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import static java.awt.event.KeyEvent.*;

public class DummyLevel implements Level
{
    public static final int START_X_POS = 80;
    public static final int START_Y_POS = 520;
    public static final int ENEMY_SPAWN_DELAY = 3000;
    private Player player;
    private ArrayList<Ladder> ladders;
    private WinFlag winFlag1;
    private Boss bossman;
    private ArrayList<Platform> platforms;
    private ArrayList<Enemy> enemies;
    private ArrayList<PowerUp> powerUps;

    public static int currentLevel = 3;
    private int enemyStartPosition = 0;

    private Timer enemySpawnTimer = new Timer();
    private Timer powerupTimer = new Timer();
    private Timer bosshitTimer = new Timer();

    public DummyLevel() {
        platforms = new ArrayList<Platform>();
        ladders = new ArrayList<Ladder>();
        enemies = new ArrayList<Enemy>();
        powerUps = new ArrayList<PowerUp>();
        initLevel();
    }

    @Override
    public void initLevel() {

        player = new Player(START_X_POS, START_Y_POS);
        Platform floor = Platform.createFloor();
        floor.addCollisionHandler(new TopCollisionHandler(floor));
        platforms.add(floor);

        Platform leftWall = Platform.createWall(-JumpmanPanel.STANDARDUNIT, 0, JumpmanPanel.HEIGHT);
        leftWall.addCollisionHandler(new RightCollisionHandler(leftWall));
        platforms.add(leftWall);

        Platform rightWall = Platform.createWall(JumpmanPanel.WIDTH, 0, JumpmanPanel.HEIGHT);
        rightWall.addCollisionHandler(new LeftCollisionHandler(rightWall));
        platforms.add(rightWall);

        LevelBuilds build = new LevelBuilds();
        build.surroundings(currentLevel);

        platforms.addAll(build.getPlatforms());
        ladders.addAll(build.getLadders());
        enemies.addAll(build.getEnemies());
        winFlag1 = build.getWinFlag1();
        powerUps.addAll(build.getPowerUps());

        if(currentLevel == 3){
            bossman = build.getBoss();
        }

        enemySpawnTimer.schedule(new AddEnemy(), ENEMY_SPAWN_DELAY);

    }

    class AddEnemy extends TimerTask{
        public void run(){
            if(enemyStartPosition == 0) {
                Enemy enemy = new Enemy(40, 400);
                enemy.setVelX(enemy.getVelX());
                enemies.add(enemy);

                enemyStartPosition = 1;
            }else if(enemyStartPosition == 1){
                Enemy enemy = new Enemy( 720, 400);
                enemy.setVelX(-enemy.getVelX());
                enemies.add(enemy);
                enemyStartPosition = 0;
            }
            enemySpawnTimer.schedule(new AddEnemy(), DummyLevel.ENEMY_SPAWN_DELAY);
        }
    }

    @Override
    public void draw(Graphics2D g2d) {
        for (Platform platform : platforms) {
            platform.draw(g2d);
        }
        for (Ladder l : ladders){
            l.draw(g2d);
        }

        if(currentLevel != 3 || bossman.healthBar == 0) {
            winFlag1.draw(g2d);
        }

        if(!JumpmanPanel.hitByEnemy) {
            player.draw(g2d);
        }

        for(Enemy enemy : enemies){
            enemy.draw(g2d);
        }

        for(PowerUp powerup : powerUps){
            powerup.draw(g2d);
        }

        if(currentLevel == 3 && bossman.healthBar != 0){
            bossman.draw(g2d);
        }

    }

    @Override
    public void tick(long deltaTime) {
        player.move(deltaTime);
        for(Enemy enemy : enemies){
            enemy.move(deltaTime);
        }
        if(currentLevel == 3) {
            bossman.move(deltaTime);
        }

        checkCollisions();
    }

    @Override
    public void handleKeyPresses(ArrayList<KeyStroke> pressedKeys) {
        boolean jumped = false;
        boolean onLadder = false;

        for(Ladder l : ladders){
            onLadder = l.checkClimbing(player);
            if(onLadder){
                break;
            }
        }

        player.setVelX(0);

        for (KeyStroke keyStroke : pressedKeys) {
            int keyCode = keyStroke.getKeyCode();
            switch (keyCode) {
                case VK_LEFT:
                    player.setVelX(-player.STANDARDSPEED);
                    break;
                case VK_RIGHT:
                    player.setVelX(player.STANDARDSPEED);
                    break;
                case VK_SPACE:
                    player.jump();
                    jumped = true;
                    break;
                case VK_UP:
                    if(onLadder){
                        player.setYPos(player.getYPos()-5);
                    }
                    break;
            }
        }
        if (!jumped) {
            player.setJumped(false);
        }

        if(onLadder){
            JumpmanPanel.GRAVITY = 0;
        }else{
            JumpmanPanel.GRAVITY = 10;
        }

    }

    @Override
    public void checkCollisions() {

        player.setInAir(true);
        for (Platform platform : platforms){
            platform.checkCollisions(player);
        }

        if(winFlag1.checkWin(player)){
            if(currentLevel != 3 || bossman.healthBar == 0) {
                JumpmanPanel.reachedFlag = true;
            }
        }

        //Check enemy collision with floors
        for(Enemy enemy : enemies){
            enemy.setInAir(true);
            for(Platform platform : platforms) {
                if (enemy.getYPos() + 20 >= platform.getYPos() && enemy.getYPos() <= platform.getYPos()+20) {
                    if (enemy.getXPos() > platform.getXPos() && enemy.getXPos() < platform.getXPos() + platform.getWidth()) {
                        enemy.setYPos(platform.getYPos()-20);
                        enemy.setInAir(false);
                    }
                }
            }
        }

        //Check enemy collision with player
        for(Enemy enemy : enemies){
            double insideEnemyY = player.getYPos()-enemy.getYPos();
            double insideEnemyX = player.getXPos()-enemy.getXPos();
            if(insideEnemyY <= 19 && -19 <= insideEnemyY){
                if(insideEnemyX <= 19 && -19 <= insideEnemyX){
                    if(JumpmanPanel.powerUpActive){
                        enemies.remove(enemy);
                        JumpmanPanel.score += 100;
                        break;
                    }else {
                        JumpmanPanel.hitByEnemy = true;
                    }
                }
            }
        }

        //Check powerup collision with player
        for(PowerUp powerUp : powerUps){
            double insidePowerUpY = player.getYPos()-powerUp.getYPos();
            double insidePowerUpX = player.getXPos()-powerUp.getXPos();
            if(insidePowerUpY <= 9 && -9 <= insidePowerUpY){
                if(insidePowerUpX <= 9 && -9 <= insidePowerUpX){
                    JumpmanPanel.powerUpActive = true;
                    powerupTimer.schedule(new EndPowerUp(), 6000);
                    powerUps.remove(powerUp);
                    JumpmanPanel.score += 150;
                    break;
                }
            }
        }

        if(currentLevel == 3 && bossman.healthBar != 0) {
            //Check top collision with top of boss
            double insideBossY = player.getYPos() - bossman.getYPos();
            double insideBossX = player.getXPos() - bossman.getXPos();
            if (insideBossY <= -65 && -79 <= insideBossY) {
                if (insideBossX <= 74 && -14 <= insideBossX) {
                    if (!JumpmanPanel.bossHit) {
                        player.setVelY(-250);
                        bosshitTimer.schedule(new EndBossHit(), 2000);
                        bossman.healthBar = bossman.healthBar - 40;
                        JumpmanPanel.score += 250;
                        JumpmanPanel.bossHit = true;
                    }
                }
            }

            //Check collision with boss otherwise
            if (player.getYPos() + 20 <= bossman.getYPos() + 20 && bossman.getYPos() - 50 <= player.getYPos()) {
                if (player.getXPos() <= bossman.getXPos() + 55 && player.getXPos() >= bossman.getXPos() + 5) {
                    if(bossman.healthBar != 0) {
                        JumpmanPanel.hitByEnemy = true;
                    }
                }
            }
        }

    }

    public static class EndPowerUp extends TimerTask{
        public void run(){
            JumpmanPanel.powerUpActive = false;
        }
    }

    public static class EndBossHit extends TimerTask{
        public void run(){
            JumpmanPanel.bossHit = false;
        }
    }

}
