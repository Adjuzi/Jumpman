package se.liu.adaan690.davas593.tddd78.jumpman.game_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.PowerUpCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.powerups.PowerUp;

import java.awt.*;

public class    PowerUpObject extends GameObject implements Collidable
{
    private PowerUpCollisionHandler collisionHandler;
    private final PowerUp powerUp;

    private boolean activated = false;

    public PowerUpObject(int xPos, int yPos, PowerUp powerUp) {
        super(xPos, yPos, JumpmanPanel.STANDARD_UNIT / 2, JumpmanPanel.STANDARD_UNIT / 2, powerUp.getColor());
        collisionHandler = new PowerUpCollisionHandler(this);
        this.powerUp = powerUp;
    }


    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());
    }

    @Override public void checkCollisions(final MovableObject movable) {
        if (collisionHandler.detectCollision(movable)) {
            collisionHandler.handleCollision(movable);
        }
    }

    public void activatePowerUp() {
        powerUp.activate();
        activated = true;
    }

    public boolean isActivated() {
        return activated;
    }
}
