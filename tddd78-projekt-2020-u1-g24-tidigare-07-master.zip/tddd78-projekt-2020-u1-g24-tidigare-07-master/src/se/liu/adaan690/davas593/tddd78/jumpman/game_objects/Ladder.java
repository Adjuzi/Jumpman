package se.liu.adaan690.davas593.tddd78.jumpman.game_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.LadderCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

import java.awt.*;

public class Ladder extends GameObject implements Collidable
{
    private LadderCollisionHandler collisionHandler;

    public Ladder(int xPos, int yPos, int width, int height) {
        super(xPos, yPos, width, height, Color.RED);
        this.collisionHandler = new LadderCollisionHandler(this);
    }

    @Override public void checkCollisions(final MovableObject movable) {
        if (collisionHandler.detectCollision(movable)) {
            collisionHandler.handleCollision(movable);
        }
    }
}
