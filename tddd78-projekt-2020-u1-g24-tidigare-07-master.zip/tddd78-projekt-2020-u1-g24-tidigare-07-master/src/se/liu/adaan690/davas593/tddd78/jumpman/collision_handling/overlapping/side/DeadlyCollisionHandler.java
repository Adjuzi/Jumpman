package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.Player;

public class DeadlyCollisionHandler extends SideCollisionHandler
{
    public DeadlyCollisionHandler(final Collidable collidable, final CollisionSide side)
    {
	super(collidable, side);
    }

    @Override public void handleCollision(final MovableObject movable) {
	/*
	Special handling especially for Player class, why an instanceof is needed in this case.
	MovableObjects are handled generally otherwise.
	 */
	//noinspection InstanceofConcreteClass
	if (movable instanceof Player) {
	    movable.kill();
	}
    }
}
