package se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player;

import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;

public abstract class NonPlayerMovableObject extends MovableObject
{
    protected static final int BLINK_PERIOD = 20;
    protected NonPlayerMovableObject(final Level level, final int xPos, final int yPos, final Color color) {
        super(level, xPos, yPos, color);
    }

    protected NonPlayerMovableObject(final Level level, final int xPos, final int yPos, final int width, final int height, final Color color) {
	super(level, xPos, yPos, width, height, color);
    }

    public void handleSideCollision(final CollisionSide collisionSide) {
	switch (collisionSide) {
	    case TOP:
	    case BOTTOM:
		setVelY(0);
		break;
	    case RIGHT:
	    case LEFT:
		setVelX(-getVelX());
		break;
	}
    }
}
