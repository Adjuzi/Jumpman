package se.liu.adaan690.davas593.tddd78.jumpman.levels;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.PlatformCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Ladder;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Platform;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.PowerUpObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.WinFlag;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player.Boss;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.spawn_points.SpawnPoint;
import se.liu.adaan690.davas593.tddd78.jumpman.powerups.KillerPowerUp;

/*
Magic numbers suppressed for this class as they represent positions on screen for level building.
They are by design hard coded as they bear no significant meaning outside level design.
As a next step, this should be extracted to for example json-files to avoid hard coded values, but this had to be skipped
in the project as we ran out of time to implement it properly.
 */
@SuppressWarnings("MagicNumber")
public class LevelFactory
{
    private JumpmanPanel jumpmanPanel;
    public LevelFactory(JumpmanPanel jumpmanPanel) {
        this.jumpmanPanel = jumpmanPanel;
    }

    public Level createLevel1() {
        Level level = new Level(jumpmanPanel);

        level.addPlatform(Platform.createStandardPlatform(200, 500, 400));
        level.addPlatform(Platform.createStandardPlatform(0, 420, 160));
        level.addPlatform(Platform.createStandardPlatform(640, 420, 160));
        level.addPlatform(Platform.createStandardPlatform(0, 220, 160));
        level.addPlatform(Platform.createStandardPlatform(620, 220, 160));
        level.addPlatform(Platform.createStandardPlatform(200, 160, 400));

        level.addLadder(new Ladder(300, JumpmanPanel.HEIGHT- JumpmanPanel.STANDARD_UNIT * 5, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 3));
        level.addLadder(new Ladder(60, 220, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 10));
        level.addLadder(new Ladder(700, 220, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 10));

        level.addWinFlag(new WinFlag(380, 120, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 2));

        level.addPowerUp(new PowerUpObject(400, 480, new KillerPowerUp(level)));

        level.addSpawnPoint(new SpawnPoint(40, 399, SpawnPoint.Direction.RIGHT, level, Level.ENEMY_SPAWN_DELAY / 2, Level.ENEMY_SPAWN_DELAY));
        level.addSpawnPoint(new SpawnPoint(720, 399, SpawnPoint.Direction.LEFT, level, 0, Level.ENEMY_SPAWN_DELAY));

        return level;
    }

    public Level createLevel2() {
        Level level = new Level(jumpmanPanel);

        level.addPlatform(Platform.createStandardPlatform(200, 500, 400));
        level.addPlatform(Platform.createStandardPlatform(0, 420, 160));
        level.addPlatform(Platform.createStandardPlatform(640, 420, 160));
        level.addPlatform(Platform.createStandardPlatform(200, 200, 400));

        Platform wall1 = Platform.createWall(140, 420, 100);
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.TOP));
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.BOTTOM));
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.RIGHT));
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.LEFT));
        level.addPlatform(wall1);

        level.addLadder(new Ladder(300, JumpmanPanel.HEIGHT- JumpmanPanel.STANDARD_UNIT * 5, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 3));
        level.addLadder(new Ladder(60, 220, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 10));
        level.addLadder(new Ladder(700, 220, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 10));

        level.addWinFlag(new WinFlag(380, 160, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 2));

        level.addSpawnPoint(new SpawnPoint(40, 399, SpawnPoint.Direction.RIGHT, level, Level.ENEMY_SPAWN_DELAY / 2, Level.ENEMY_SPAWN_DELAY));
        level.addSpawnPoint(new SpawnPoint(720, 399, SpawnPoint.Direction.LEFT, level, 0, Level.ENEMY_SPAWN_DELAY));

        return level;
    }

    public Level createLevel3() {
        Level level = new Level(jumpmanPanel);

        level.addPlatform(Platform.createStandardPlatform(200, 500, 400));
        level.addPlatform(Platform.createStandardPlatform(0, 420, 160));
        level.addPlatform(Platform.createStandardPlatform(640, 420, 160));
        level.addPlatform(Platform.createStandardPlatform(200, 350, 400));

        Platform wall1 = Platform.createWall(140, 420, 100);
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.TOP));
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.BOTTOM));
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.RIGHT));
        wall1.addCollisionHandler(new PlatformCollisionHandler(wall1, CollisionSide.LEFT));
        level.addPlatform(wall1);

        level.addLadder(new Ladder(300, JumpmanPanel.HEIGHT- JumpmanPanel.STANDARD_UNIT * 5, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 3));
        level.addLadder(new Ladder(60, 220, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 10));
        level.addLadder(new Ladder(700, 220, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 10));

        level.addWinFlag(new WinFlag(380, 310, JumpmanPanel.STANDARD_UNIT, JumpmanPanel.STANDARD_UNIT * 2));

        level.addSpawnPoint(new SpawnPoint(40, 399, SpawnPoint.Direction.RIGHT, level, Level.ENEMY_SPAWN_DELAY / 2, Level.ENEMY_SPAWN_DELAY));
        level.addSpawnPoint(new SpawnPoint(720, 399, SpawnPoint.Direction.LEFT, level, 0, Level.ENEMY_SPAWN_DELAY));

        level.addBoss(Boss.createStandardBoss( level,300, 280));

        return level;
    }
}
