package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side;

import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.OverlappingCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

public abstract class SideCollisionHandler extends OverlappingCollisionHandler
{
    public static final double COLLISION_ADD_CONSTANT = 0.0001;
    protected final CollisionSide collisionSide;


    protected SideCollisionHandler(final Collidable collidable, final CollisionSide side) {
        super(collidable);
        collisionSide = side;
    }

    /**
     * Detects a collision from a given side
     * <p>
     *     Builds upon OverlappingCollisionHandler. Checks if movable overlaps the collidable.
     *     If so, it checks has passed through the given collisionSide in the last frame, and if so, detects a sideCollision
     * </p>
     * @param movable
     * @return Bool whether collision was detected or not.
     */
    @Override public boolean detectCollision(final MovableObject movable) {
        if (super.detectCollision(movable)) {
            double collidableYPos;
            double collidableXPos;
            /*
            Special check was needed for collisions with other movable objects, in order to account for their movement
            when detecting a collision. Did not motivate the use of a separate class or method.
             */
            //noinspection InstanceofConcreteClass
            if (collidable instanceof MovableObject) {
                collidableYPos = ((MovableObject) collidable).getPreviousYPos();
                collidableXPos = ((MovableObject) collidable).getPreviousXPos();
            } else {
                collidableYPos = collidable.getYPos();
                collidableXPos = collidable.getXPos();
            }
            switch (collisionSide) {
                case TOP:
                    return movable.getPreviousYPos() + movable.getHeight() < collidableYPos;
                case BOTTOM:
                    return movable.getPreviousYPos() > collidableYPos + collidable.getHeight();
                case LEFT:
                    return movable.getPreviousXPos() + movable.getWidth() < collidableXPos;
                case RIGHT:
                    return movable.getPreviousXPos() > collidableXPos + collidable.getWidth();
                default:
                    break;
            }
        }
        return false;
    }
}
