package se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.GameObject;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;

public abstract class MovableObject extends GameObject
{
    public static final double STANDARD_SPEED = 200;
    public static final int STANDARD_WEIGHT = 50;
    protected Level level;
    protected double previousXPos;
    protected double previousYPos;
    protected double velX = 0;
    protected double velY = 0;
    protected int weight = STANDARD_WEIGHT;

    protected boolean affectedByGravity = true;
    protected boolean inAir = false;
    protected boolean dead = false;

    protected MovableObject(final Level level, final int xPos, final int yPos, final Color color) {
	super(xPos, yPos, color);
	this.level = level;
	this.previousXPos = xPos;
	this.previousYPos = yPos;
    }

    protected MovableObject(final Level level, final int xPos, final int yPos, final int width, final int height, final Color color) {
	super(xPos, yPos, width, height, color);
	this.level = level;
	previousXPos = xPos;
	previousYPos = yPos;
    }

    public void setInAir(final boolean inAir) {
	this.inAir = inAir;
    }

    public void move(final long deltaTime) {
	previousXPos = xPos;
	xPos += velX * ((double) deltaTime / JumpmanPanel.NANO_SECOND);

	previousYPos = yPos;
	yPos += velY * ((double) deltaTime / JumpmanPanel.NANO_SECOND);
    }

    public boolean isDead() {
        return dead;
    }

    public void kill() {
        dead = true;
    }

    public void setAffectedByGravity(boolean affectedByGravity) {
	this.affectedByGravity = affectedByGravity;
    }

    public double getPreviousXPos() {
	return previousXPos;
    }

    public double getPreviousYPos() {
	return previousYPos;
    }

    public double getVelX() {
	return velX;
    }

    public void setVelX(final double velX) {
	this.velX = velX;
    }

    public void setVelY(final double velY) {
	this.velY = velY;
    }

    public boolean isAffectedByGravity() {
	return affectedByGravity;
    }

    public abstract void handleSideCollision(final CollisionSide collisionSide);
}
