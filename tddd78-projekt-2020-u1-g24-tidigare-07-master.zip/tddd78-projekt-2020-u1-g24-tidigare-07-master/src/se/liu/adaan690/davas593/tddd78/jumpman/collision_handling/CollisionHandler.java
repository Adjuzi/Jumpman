package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

public abstract class CollisionHandler
{
    public final Collidable collidable;

    protected CollisionHandler(Collidable collidable) {
        this.collidable = collidable;
    }

    public abstract boolean detectCollision(MovableObject movable);
    public abstract void handleCollision(MovableObject movable);
}
