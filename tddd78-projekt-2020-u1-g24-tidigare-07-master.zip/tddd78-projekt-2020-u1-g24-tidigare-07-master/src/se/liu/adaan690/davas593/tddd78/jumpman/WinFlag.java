package se.liu.adaan690.davas593.tddd78.jumpman;

import java.awt.*;

public class WinFlag {
    private int xPos;
    private int yPos;
    private int height;
    private int width;

    public WinFlag(int xPos, int yPos, int height, int width) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.height = height;
        this.width = width;
    }

    public boolean checkWin(Player player) {
        if(player.getXPos()+JumpmanPanel.STANDARDUNIT > xPos && player.getXPos() < xPos +width){
            return player.getYPos() < yPos + height && player.getYPos() > yPos - JumpmanPanel.STANDARDUNIT;
        }
        return false;
    }

    public void draw(Graphics g) {
        g.setColor(Color.gray);
        g.fillRect(xPos, yPos, width/5, height);
        g.setColor(Color.yellow);
        g.fillRect(xPos +width/5, yPos, width*4/5, height/2);
    }
}
