package se.liu.adaan690.davas593.tddd78.jumpman.levels;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public interface Level {

    void initLevel();
    void draw(Graphics2D g2d);
    void tick(long deltaTime);
    void handleKeyPresses(ArrayList<KeyStroke> pressedKeys);
    void checkCollisions();
}
