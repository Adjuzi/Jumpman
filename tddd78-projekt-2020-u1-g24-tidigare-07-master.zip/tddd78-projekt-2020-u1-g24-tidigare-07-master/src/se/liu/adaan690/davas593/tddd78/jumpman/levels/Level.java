package se.liu.adaan690.davas593.tddd78.jumpman.levels;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.PlatformCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Ladder;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Platform;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.PowerUpObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.WinFlag;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.Player;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player.Boss;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player.Enemy;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.spawn_points.SpawnPoint;
import se.liu.adaan690.davas593.tddd78.jumpman.powerups.PowerUp;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static java.awt.event.KeyEvent.*;

public class Level
{
    public static final int START_X_POS = 80;
    public static final int START_Y_POS = 200;
    public static final long ENEMY_SPAWN_DELAY = 6000;
    public static final int POWER_UP_CATCH_SCORE = 150;
    public static final int ENEMY_KILL_SCORE = 100;
    public static final int BOSS_HIT_SCORE = 250;
    private static final int BASE_GRAVITY = 10;

    private JumpmanPanel jumpmanPanel;
    private Player player;
    private List<Ladder> ladders;
    private WinFlag winFlag = null;
    private Boss bossman = null;
    private List<Platform> platforms;
    private List<Enemy> enemies;
    private List<PowerUpObject> powerUpObjects;
    private List<SpawnPoint> enemySpawnPoints;
    private PowerUp activePowerUp = null;

    private int gravity = BASE_GRAVITY;

    private boolean winStateReached = false;
    private boolean lostStateReached = false;

    public Level(JumpmanPanel jumpmanPanel) {
        this.jumpmanPanel = jumpmanPanel;
        player = new Player(this, START_X_POS, START_Y_POS);

        platforms = new ArrayList<>();
        ladders = new ArrayList<>();
        enemies = new LinkedList<>();
        powerUpObjects = new ArrayList<>();
        enemySpawnPoints = new ArrayList<>();
        setUpLevel();
    }

    private void setUpLevel() {

        platforms.add(Platform.createRoof());
        platforms.add(Platform.createFloor());

        Platform leftWall = Platform.createWall(-JumpmanPanel.STANDARD_UNIT, 0, JumpmanPanel.HEIGHT);
        leftWall.addCollisionHandler(new PlatformCollisionHandler(leftWall, CollisionSide.RIGHT));
        platforms.add(leftWall);

        Platform rightWall = Platform.createWall(JumpmanPanel.WIDTH, 0, JumpmanPanel.HEIGHT);
        rightWall.addCollisionHandler(new PlatformCollisionHandler(rightWall, CollisionSide.LEFT));
        platforms.add(rightWall);
    }

    public void startLevel() {
        for (SpawnPoint spawnPoint : enemySpawnPoints) {
            spawnPoint.activate();
        }
    }

    public void stopLevel() {
        for (SpawnPoint spawnPoint : enemySpawnPoints) {
            spawnPoint.deactivate();
        }
    }

    public void draw(Graphics2D g2d) {
        for (Platform platform : platforms) {
            platform.draw(g2d);
        }
        for (Ladder l : ladders){
            l.draw(g2d);
        }

        if(bossman == null || bossman.isDead()) {
            winFlag.draw(g2d);
        }

        if(!lostStateReached) {
            player.draw(g2d);
        }

        for(Enemy enemy : enemies){
            enemy.draw(g2d);
        }

        for(PowerUpObject powerup : powerUpObjects){
            powerup.draw(g2d);
        }

        if(bossman != null && !bossman.isDead()){
            bossman.draw(g2d);
        }

    }

    public void tick(long deltaTime) {
        player.move(deltaTime);
        for(Enemy enemy : enemies){
            enemy.move(deltaTime);
        }
        if(bossman != null) {
            bossman.move(deltaTime);
        }

        checkCollisions();
        checkGameState();
    }

    public void handleKeyPresses(List<KeyStroke> pressedKeys) {
        boolean jumped = false;

        player.setVelX(0);

        if (player.isClimbing()) {
            player.setVelY(0);
        }

        for (KeyStroke keyStroke : pressedKeys) {
            int keyCode = keyStroke.getKeyCode();
            switch (keyCode) {
                case VK_LEFT:
                    player.setVelX(-MovableObject.STANDARD_SPEED);
                    break;
                case VK_RIGHT:
                    player.setVelX(MovableObject.STANDARD_SPEED);
                    break;
                case VK_SPACE:
                    player.jump();
                    jumped = true;
                    player.setClimbing(false);
                    break;
                case VK_UP:
                    if(!player.isAffectedByGravity()){
                        player.setVelY(-MovableObject.STANDARD_SPEED);
                        player.setClimbing(true);
                    }
                    break;
                case VK_DOWN:
                    if (!player.isAffectedByGravity()) {
                        player.setVelY(MovableObject.STANDARD_SPEED);
                        player.setClimbing(true);
                    }
                    break;
            }
        }

        if (!jumped) {
            player.setJumping(false);
        }
    }

    private void checkCollisions() {

        player.setInAir(true);
        for (Platform platform : platforms){
            platform.checkCollisions(player);
        }

        player.setAffectedByGravity(true);
        for (Ladder ladder : ladders) {
            ladder.checkCollisions(player);
        }
        if (player.isAffectedByGravity()) {
            player.setClimbing(false);
        }

        if (winFlag != null && (bossman == null || bossman.isDead())) {
            winFlag.checkCollisions(player);
        }

        for (Enemy enemy : enemies) {
            enemy.checkCollisions(player);

            for (Platform platform : platforms) {
                platform.checkCollisions(enemy);
            }
        }

        for (PowerUpObject powerUpObject : powerUpObjects) {
            powerUpObject.checkCollisions(player);
        }

        if (bossman != null) {
            bossman.checkCollisions(player);

            for (Platform platform : platforms) {
                platform.checkCollisions(bossman);
            }
        }
    }

    private void checkGameState() {
           if (player.isDead()) {
               lostStateReached = true;
           }

           int enemiesBefore = enemies.size();
           enemies.removeIf(MovableObject::isDead);
           jumpmanPanel.addScore(ENEMY_KILL_SCORE*(enemiesBefore - enemies.size()));

           int powerUpsBefore = powerUpObjects.size();
           powerUpObjects.removeIf(PowerUpObject::isActivated);
           jumpmanPanel.addScore(POWER_UP_CATCH_SCORE*(powerUpsBefore - powerUpObjects.size()));

           if ((winFlag == null || winFlag.isReached()) && (bossman == null || bossman.isDead())) {
               System.out.println("winstate");
               winStateReached = true;
           }

           if (bossman != null) {
               if (bossman.isHitDetected()) {
                   jumpmanPanel.addScore(BOSS_HIT_SCORE);
                   bossman.setHitDetected(false);
               }
           }
       }

    public void activatePowerUp(PowerUp powerUp) {
        if (activePowerUp != null) {
            activePowerUp.cancelPowerUp();
        }
        activePowerUp = powerUp;
    }

    public void deactivatePowerUp(PowerUp powerUp) {
        if (activePowerUp.equals(powerUp)) {
            activePowerUp = null;
        }
    }

    public boolean isWinStateReached() {
            return winStateReached;
        }

    public boolean isLostStateReached() {
        return lostStateReached;
    }

    public int getGravity() {
        return gravity;
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }

    public void addEnemy(Enemy enemy) {
        enemies.add(enemy);
    }

    public void addPlatform(Platform platform) {
        platforms.add(platform);
    }

    public void addPowerUp(PowerUpObject powerUpObject) {
        powerUpObjects.add(powerUpObject);
    }

    public void addBoss(Boss boss) {
        bossman = boss;
    }

    public void addLadder(Ladder ladder) {
        ladders.add(ladder);
    }

    public void addWinFlag(WinFlag winFlag) {
        this.winFlag = winFlag;
    }

    public void addSpawnPoint(SpawnPoint spawnPoint) {
        enemySpawnPoints.add(spawnPoint);
    }
}
