package se.liu.adaan690.davas593.tddd78.jumpman.game_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.WinFlagCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

import java.awt.*;

public class WinFlag extends GameObject implements Collidable
{
    private boolean reached;

    private WinFlagCollisionHandler collisionHandler;

    public WinFlag(int xPos, int yPos, int width, int height) {
        super(xPos, yPos, width, height, Color.YELLOW);
        reached = false;
        collisionHandler = new WinFlagCollisionHandler(this);
    }

    public boolean isReached() {
        return reached;
    }

    public void setReached(final boolean reached) {
        this.reached = reached;
    }

    public void draw(Graphics g) {
        g.setColor(Color.gray);
        g.fillRect(getIntXPos(), getIntYPos(), width/5, height);
        g.setColor(getColor());
        g.fillRect(getIntXPos() +width/5, getIntYPos(), width*4/5, height/2);
    }

    @Override public void checkCollisions(final MovableObject movable) {
        if (collisionHandler.detectCollision(movable)) {
            collisionHandler.handleCollision(movable);
        }
    }
}
