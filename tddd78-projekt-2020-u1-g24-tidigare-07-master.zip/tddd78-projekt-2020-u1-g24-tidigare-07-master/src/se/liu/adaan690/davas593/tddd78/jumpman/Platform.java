package se.liu.adaan690.davas593.tddd78.jumpman;

import se.liu.adaan690.davas593.tddd78.jumpman.collisions.CollisionHandler;

import java.awt.*;
import java.util.ArrayList;

public class Platform implements Collidable {
    private double xPos;
    private double yPos;
    private int height;
    private int width;
    private Color color = Color.blue;

    private ArrayList<CollisionHandler> collisionHandlers = new ArrayList<CollisionHandler>();

    public Platform(int xPos, int yPos, int width, int height) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.width = width;
        this.height = height;
    }

    public double getXPos() {
        return xPos;
    }

    public double getYPos() {
        return yPos;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getIntX_pos() {
        return (int) Math.round(xPos);
    }

    public int getIntY_pos() {
        return (int) Math.round(yPos);
    }

    public Color getColor() {
        return color;
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(getIntX_pos(), getIntY_pos(), getWidth(), getHeight());
    }

    public static Platform createFloor() {
        return new Platform(0, JumpmanPanel.HEIGHT-2*JumpmanPanel.STANDARDUNIT, JumpmanPanel.WIDTH, JumpmanPanel.STANDARDUNIT);
    }

    public static Platform createStandardPlatform(int xPos, int yPos, int width) {
        return new Platform(xPos, yPos, width, JumpmanPanel.STANDARDUNIT);
    }

    public static Platform createWall(int xPos, int yPos, int height) {
        return new Platform(xPos, yPos, JumpmanPanel.STANDARDUNIT, height);
    }

    public void addCollisionHandler(CollisionHandler collisionHandler) {
        collisionHandlers.add(collisionHandler);
    }

    @Override
    public void checkCollisions(Player player) {
        for (CollisionHandler collisionHandler : collisionHandlers) {
            collisionHandler.checkCollision(player);
        }
    }
}
