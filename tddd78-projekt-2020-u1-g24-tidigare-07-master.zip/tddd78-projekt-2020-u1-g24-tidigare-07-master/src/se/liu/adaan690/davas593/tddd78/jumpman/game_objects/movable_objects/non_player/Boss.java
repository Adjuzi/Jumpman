package se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.non_player;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.CollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.BossDamageCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.DeadlyCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class Boss extends NonPlayerMovableObject implements Collidable
{

    private static final int HEALTH_BAR_X_POS = 600;
    private static final int HEALTH_BAR_Y_POS = 80;
    private static final int BOSS_BASE_SPEED = 50;
    private static final int BOSS_BASE_HEALTH = 160;
    private static final long BOSS_HIT_COOLDOWN = 2000;
    private static final int LEFT_BOUND = 250;
    private static final int RIGHT_BOUND = 550;

    private List<CollisionHandler> collisionHandlers = new ArrayList<>();

    private int turner = 0;

    private int hitCounter = 0;

    private boolean hitDetected = false;
    private boolean inHitCooldown = false;
    private Timer hitCooldownTimer;
    private int health = BOSS_BASE_HEALTH;

    public Boss(final Level level, int xPos, int yPos) {
        super(level, xPos, yPos, JumpmanPanel.STANDARD_UNIT * 3, JumpmanPanel.STANDARD_UNIT * 3, Color.pink);
        setVelX(BOSS_BASE_SPEED);
        hitCooldownTimer = new Timer();
    }

    public boolean isInHitCooldown() {
        return inHitCooldown;
    }

    public boolean isHitDetected() {
        return hitDetected;
    }

    public void setHitDetected(final boolean hitDetected) {
        this.hitDetected = hitDetected;
    }

    public void move(long deltaTime){
        super.move(deltaTime);
        velY += level.getGravity() * weight * ((double) deltaTime / JumpmanPanel.NANO_SECOND);

        if( turner == 0 && xPos > RIGHT_BOUND){
            velX = -velX;
            turner = 1;
        }else if( turner == 1 && xPos < LEFT_BOUND){
            velX = -velX;
            turner = 0;
        }
    }

    public void draw(Graphics g) {
        /*
        Support for blinking in case of being hit. Time in frames specified based on BLINKPERIOD.
        White half of the time, colored half. Always colored if not blinking
         */
        if(inHitCooldown && hitCounter < BLINK_PERIOD){
            hitCounter++;
        }else{
            hitCounter = 0;
        }

        /*
        Single row is repeated. Moving it outside of if-statement results in less readable code
        as set up for it is done inside the statement.
         */
        //noinspection IfStatementWithIdenticalBranches
        if(hitCounter < BLINK_PERIOD / 2) {
            //Left foot
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(getIntXPos(), getIntYPos() + (5*getHeight())/6, getWidth()/3, getHeight()/6);
            //Right foot
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(getIntXPos() + (2*getWidth()/3), getIntYPos() + (5 * getHeight()) / 6, getWidth() / 3, getHeight() / 6);
            //Body
            g.setColor(getColor());
            g.fillRect(getIntXPos() + (getWidth()/4), getIntYPos() + (getHeight()/3), 2 * getWidth()/4, 3* getHeight()/6);
            //Head
            g.setColor(Color.ORANGE);
            g.fillRect(getIntXPos() + getWidth()/6, getIntYPos(), 4*getWidth()/6, getHeight() / 3);
        }else{
            //Left foot
            g.setColor(Color.WHITE);
            g.fillRect(getIntXPos(), getIntYPos() + (5 * getHeight()) / 6, getWidth() / 3, getHeight() / 6);
            //Right foot
            g.fillRect(getIntXPos() + (2 * getWidth() / 3), getIntYPos() + (5 * getHeight()) / 6, getWidth() / 3, getHeight() / 6);
            //Body
            g.fillRect(getIntXPos() + (getWidth() / 4), getIntYPos() + (getHeight() / 3), 2 * getWidth() / 4,
                       3 * getHeight() / 6);
            //Head
            g.fillRect(getIntXPos() + getWidth() / 6, getIntYPos(), 4 * getWidth() / 6, getHeight() / 3);
        }

        g.setColor(Color.RED);
        g.fillRect(HEALTH_BAR_X_POS, HEALTH_BAR_Y_POS, health, 10);
    }

    public void addCollisionHandler(CollisionHandler collisionHandler) {
        collisionHandlers.add(collisionHandler);
    }

    @Override public void checkCollisions(final MovableObject movable) {
        for (CollisionHandler collisionHandler : collisionHandlers) {
            if (collisionHandler.detectCollision(movable)) {
                collisionHandler.handleCollision(movable);
            }
        }
    }

    public void handleHit(int damage) {
        health -= damage;
        hitDetected = true;
        if (health <= 0) {
            kill();
        } else {
            inHitCooldown = true;
            hitCooldownTimer.schedule(new EndHitCooldownTask(), BOSS_HIT_COOLDOWN);
        }
    }

    public static Boss createStandardBoss(final Level level, int xPos, int yPos) {
        Boss boss = new Boss(level, xPos, yPos);
        boss.addCollisionHandler(new BossDamageCollisionHandler(boss, CollisionSide.TOP));
        boss.addCollisionHandler(new DeadlyCollisionHandler(boss, CollisionSide.BOTTOM));
        boss.addCollisionHandler(new DeadlyCollisionHandler(boss, CollisionSide.RIGHT));
        boss.addCollisionHandler(new DeadlyCollisionHandler(boss, CollisionSide.LEFT));

        return boss;
    }

    private class EndHitCooldownTask extends TimerTask {
        @Override public void run() {
            inHitCooldown = false;
        }
    }
}
