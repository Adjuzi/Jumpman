package se.liu.adaan690.davas593.tddd78.jumpman;

import java.awt.*;

public class Player {
    public final double JUMPFORCE = -300;
    public final double STANDARDSPEED = 200;

    private double xPos;
    private double yPos;
    private double previousXPos;
    private double previousYPos;

    private double velX = 0;
    private double velY = 0;

    private boolean jumped = false;
    private boolean inAir = false;


    private int width = JumpmanPanel.STANDARDUNIT;
    private int height = JumpmanPanel.STANDARDUNIT;
    private double weight = 50;
    private Color color = Color.green;

    public Player(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.previousXPos = xPos;
        this.previousYPos = yPos;
    }

    public Player(int xPos, int yPos, int width, int height) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.previousXPos = xPos;
        this.previousYPos = yPos;
        this.width = width;
        this.height = height;
    }

    public void setXPos(double xPos) {
        this.xPos = xPos;
    }

    public void setYPos(double yPos) {
        this.yPos = yPos;
    }

    public void setVelX(double velX) {
        this.velX = velX;
    }

    public void setVelY(double velY) {
        this.velY = velY;
    }

    public void setJumped(boolean jumped) {
        this.jumped = jumped;
    }

    public void setInAir(boolean inAir) {
        this.inAir = inAir;
    }

    public double getXPos() {
        return xPos;
    }

    public double getYPos() {
        return yPos;
    }

    public double getPreviousXPos() { return previousXPos; }

    public double getPreviousYPos() { return previousYPos; }

    public int getIntXPos() {
        return (int) Math.round(xPos);
    }

    public int getIntYPos() {
        return (int) Math.round(yPos);
    }

    public double getVelX() {
        return velX;
    }

    public double getVelY() {
        return velY;
    }

    public Color getColor() {
        return color;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void jump() {
        if (!inAir && !jumped) {
            setVelY(JUMPFORCE);
            jumped = true;
        }
    }

    public void move(long deltaTime){
        previousXPos = xPos;
        xPos += velX * ((double) deltaTime/JumpmanPanel.NANOSECOND);

        previousYPos = yPos;
        yPos += velY * ((double) deltaTime/JumpmanPanel.NANOSECOND);
        velY += JumpmanPanel.GRAVITY * weight * ((double) deltaTime/JumpmanPanel.NANOSECOND);
    }

    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());

        if(JumpmanPanel.powerUpActive && JumpmanPanel.powerUpColor < 10){
            g.setColor(Color.WHITE);
            g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());
            JumpmanPanel.powerUpColor++;
        }else{
            g.setColor(Color.GREEN);
            g.fillRect(getIntXPos(), getIntYPos(), getWidth(), getHeight());
            JumpmanPanel.powerUpColor++;
            if(JumpmanPanel.powerUpColor > 20){
                JumpmanPanel.powerUpColor = 0;
            }
        }
    }
}
