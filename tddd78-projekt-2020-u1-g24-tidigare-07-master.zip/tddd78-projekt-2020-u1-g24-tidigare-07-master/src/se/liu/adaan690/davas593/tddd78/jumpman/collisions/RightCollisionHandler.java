package se.liu.adaan690.davas593.tddd78.jumpman.collisions;

import se.liu.adaan690.davas593.tddd78.jumpman.Collidable;
import se.liu.adaan690.davas593.tddd78.jumpman.Player;

public class RightCollisionHandler extends CollisionHandler {

    public RightCollisionHandler(Collidable collidable) {
        super(collidable);
    }

    @Override
    public void checkCollision(Player player) {
        if(player.getXPos() <= collidable.getXPos()+collidable.getWidth()
                && player.getPreviousXPos() > collidable.getXPos()+collidable.getWidth()) {
            if (player.getYPos() + player.getHeight() > collidable.getYPos() && player.getYPos() <= collidable.getYPos() + collidable.getHeight()) {
                player.setXPos(collidable.getXPos() + collidable.getWidth() + 0.0001);
            }
        }
    }
}
