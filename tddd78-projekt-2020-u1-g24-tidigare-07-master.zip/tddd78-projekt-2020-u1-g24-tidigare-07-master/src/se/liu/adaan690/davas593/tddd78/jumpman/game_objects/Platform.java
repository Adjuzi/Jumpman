package se.liu.adaan690.davas593.tddd78.jumpman.game_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.CollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.CollisionSide;
import se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side.PlatformCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Platform extends GameObject implements Collidable
{

    private List<CollisionHandler> collisionHandlers = new ArrayList<>();

    public Platform(int xPos, int yPos, int width, int height) {
        super(xPos, yPos, width, height, Color.BLUE);
    }

    public static Platform createRoof() {
        Platform platform = new Platform(0, -JumpmanPanel.STANDARD_UNIT, JumpmanPanel.WIDTH, JumpmanPanel.STANDARD_UNIT);
        platform.addCollisionHandler(new PlatformCollisionHandler(platform, CollisionSide.BOTTOM));
        return platform;
    }

    public static Platform createFloor() {
        Platform platform = new Platform(0, JumpmanPanel.HEIGHT - 2 * JumpmanPanel.STANDARD_UNIT, JumpmanPanel.WIDTH, JumpmanPanel.STANDARD_UNIT);
        platform.addCollisionHandler(new PlatformCollisionHandler(platform, CollisionSide.TOP));
        return platform;
    }

    public static Platform createStandardPlatform(int xPos, int yPos, int width) {
        Platform platform = new Platform(xPos, yPos, width, JumpmanPanel.STANDARD_UNIT);
        platform.addCollisionHandler(new PlatformCollisionHandler(platform, CollisionSide.TOP));
        return platform;
    }

    public static Platform createWall(int xPos, int yPos, int height) {
        return new Platform(xPos, yPos, JumpmanPanel.STANDARD_UNIT, height);
    }

    public void addCollisionHandler(CollisionHandler collisionHandler) {
        collisionHandlers.add(collisionHandler);
    }

    @Override
    public void checkCollisions(MovableObject movable) {
        for (CollisionHandler collisionHandler : collisionHandlers) {
            if (collisionHandler.detectCollision(movable)) {
                collisionHandler.handleCollision(movable);
            }
        }
    }
}
