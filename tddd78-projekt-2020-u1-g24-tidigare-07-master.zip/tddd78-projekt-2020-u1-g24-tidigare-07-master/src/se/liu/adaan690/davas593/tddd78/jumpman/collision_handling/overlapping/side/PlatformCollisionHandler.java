package se.liu.adaan690.davas593.tddd78.jumpman.collision_handling.overlapping.side;

import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.Platform;
import se.liu.adaan690.davas593.tddd78.jumpman.game_objects.movable_objects.MovableObject;

public class PlatformCollisionHandler extends SideCollisionHandler
{
    public PlatformCollisionHandler(final Platform platform, final CollisionSide side)
    {
	super(platform, side);
    }

    @Override public void handleCollision(final MovableObject movable) {
	switch (collisionSide) {
	    case TOP:
		movable.setYPos(collidable.getYPos() - movable.getHeight() - COLLISION_ADD_CONSTANT);
		break;
	    case BOTTOM:
		movable.setYPos(collidable.getYPos() + collidable.getHeight() + COLLISION_ADD_CONSTANT);
		break;
	    case LEFT:
		movable.setXPos(collidable.getXPos() - movable.getWidth() - COLLISION_ADD_CONSTANT);
		break;
	    case RIGHT:
		movable.setXPos(collidable.getXPos() + collidable.getWidth() + COLLISION_ADD_CONSTANT);
		break;
	}
	movable.handleSideCollision(collisionSide);
    }
}
