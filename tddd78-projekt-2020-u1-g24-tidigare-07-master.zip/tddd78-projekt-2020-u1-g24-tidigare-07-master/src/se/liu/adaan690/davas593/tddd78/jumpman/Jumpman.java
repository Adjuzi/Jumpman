package se.liu.adaan690.davas593.tddd78.jumpman;

public class Jumpman {

    public static final String GAMETITLE = "Jumpman";

    public static void main(String[] args) {
        new JumpmanFrame(GAMETITLE);
    }
}
