package se.liu.adaan690.davas593.tddd78.jumpman;

public class Jumpman {

    public static final String GAME_TITLE = "Jumpman";

    public static void main(String[] args) {
        /*
        As this is a main method that simply starts a JumpmanFrame, it does not need to save that Frame,
        which is why we deem it reasonable to suppress this warning in this case.
         */
        //noinspection ResultOfObjectAllocationIgnored
        new JumpmanFrame(GAME_TITLE);
    }
}
