package se.liu.adaan690.davas593.tddd78.jumpman;

import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.LevelFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JumpmanPanel extends JPanel implements Runnable {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int STANDARD_UNIT = 20;
    public static final long NANO_SECOND = 1000000000;
    private static final int SCORE_FONT_SIZE = 24;
    private static final int LEVEL_COMPLETED_SCORE = 1000;
    private static final String COMPLETED_STRING = "Game completed!";
    private static final String GAME_OVER_STRING = "Game over!";

    private Thread thread;
    private volatile boolean running;
    private static final int FPS = 60;
    private static final long FRAME_LENGTH = NANO_SECOND / FPS;

    private int score = 0;
    private boolean gameCompleted = false;
    private boolean gameOver = false;

    private Level currentLevel = null;
    private List<Level> levels;
    private Iterator<Level> levelIterator = null;

    private List<KeyStroke> pressedKeys;

    public JumpmanPanel(){
        levels = new ArrayList<>();
        pressedKeys = new ArrayList<>();

        initGame();
        System.out.println("game initialized");
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        requestFocus();
    }

    private void initGame(){
        setUpLevels();
        setKeyBindings();

        thread = new Thread(this);
        running = true;
        thread.start();
    }

    /*
    Magic numbers introduced as they represent arbitrary fixed points on screen for drawing strings.
    Not reused anywhere else, or bear any significant meaning.
     */
    @SuppressWarnings("MagicNumber") @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        final Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(Color.BLACK);
        g2d.fillRect(0,0, WIDTH, HEIGHT);

        currentLevel.draw(g2d);

        if(gameCompleted || gameOver) {
            String message = "";
            if (gameCompleted) {
                message = COMPLETED_STRING;
            } else {
                message = GAME_OVER_STRING;
            }
            g2d.setColor(Color.WHITE);
            g2d.drawString(message, 400, 200);

            g2d.drawString("Choose to play again in file menu", 400, 300);
        }

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("default", Font.BOLD, SCORE_FONT_SIZE));
        g2d.drawString(String.valueOf(score), 680, 50);
    }

    private void tick(long deltaTime){
        currentLevel.tick(deltaTime);
    }

    @Override
    public void run() {
        long lastFrame = System.nanoTime();
        System.out.println("thread started");
        levelIterator = levels.iterator();

        while(running) {
            if (levelIterator.hasNext()) {
                currentLevel = levelIterator.next();
                currentLevel.startLevel();
            } else {
                gameCompleted = true;
                running = false;
            }

            while (!currentLevel.isWinStateReached() && !currentLevel.isLostStateReached()) {
                long currentTime = System.nanoTime();
                long deltaTime = currentTime - lastFrame;

                if (deltaTime >= FRAME_LENGTH) {
                    lastFrame = currentTime;

                    currentLevel.handleKeyPresses(pressedKeys);
                    tick(deltaTime);
                    this.repaint();
                }
            }

            score += LEVEL_COMPLETED_SCORE;

            if (currentLevel.isLostStateReached()) {
                gameOver = true;
                running = false;
                //Remove previously added level score if it was ended because of lost state.
                score -= LEVEL_COMPLETED_SCORE;
            }

            currentLevel.stopLevel();
        }

        repaint();
    }

    public void addScore(int scoreToAdd) {
            score += scoreToAdd;
        }

    private void setUpLevels() {
        LevelFactory levelFactory = new LevelFactory(this);
        levels.add(levelFactory.createLevel1());
        levels.add(levelFactory.createLevel2());
        levels.add(levelFactory.createLevel3());
    }

    private void setKeyBindings() {
        final InputMap in = this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        final ActionMap act = this.getActionMap();

        in.put(KeyStroke.getKeyStroke("LEFT"), "pressLeft");
        in.put(KeyStroke.getKeyStroke("released LEFT"), "releaseLeft");
        act.put("pressLeft", new PressAction("LEFT"));
        act.put("releaseLeft", new ReleaseAction("LEFT"));

        in.put(KeyStroke.getKeyStroke("RIGHT"), "pressRight");
        in.put(KeyStroke.getKeyStroke("released RIGHT"), "releaseRight");
        act.put("pressRight", new PressAction("RIGHT"));
        act.put("releaseRight", new ReleaseAction("RIGHT"));

        in.put(KeyStroke.getKeyStroke("SPACE"), "pressSpace");
        in.put(KeyStroke.getKeyStroke("released SPACE"), "releaseSpace");
        act.put("pressSpace", new PressAction("SPACE"));
        act.put("releaseSpace", new ReleaseAction("SPACE"));

        in.put(KeyStroke.getKeyStroke("UP"), "pressUp");
        in.put(KeyStroke.getKeyStroke("released UP"), "releaseUp");
        act.put("pressUp", new PressAction("UP"));
        act.put("releaseUp", new ReleaseAction("UP"));

        in.put(KeyStroke.getKeyStroke("DOWN"), "pressDown");
        in.put(KeyStroke.getKeyStroke("released DOWN"), "releaseDown");
        act.put("pressDown", new PressAction("DOWN"));
        act.put("releaseDown", new ReleaseAction("DOWN"));
    }

    private class PressAction extends AbstractAction {
        private KeyStroke key;

        @Override public void actionPerformed(final ActionEvent e){
            if (!pressedKeys.contains(key)) {
                pressedKeys.add(key);
            }
        }

        private PressAction(String keyString) {
            key = KeyStroke.getKeyStroke(keyString);
        }
    }

    private class ReleaseAction extends AbstractAction {
        private KeyStroke key;

        @Override public void actionPerformed(final ActionEvent e){
            pressedKeys.remove(key);
        }

        private ReleaseAction(String keyString) {
            key = KeyStroke.getKeyStroke(keyString);
        }
    }

}
