package se.liu.adaan690.davas593.tddd78.jumpman;

import se.liu.adaan690.davas593.tddd78.jumpman.levels.DummyLevel;
import se.liu.adaan690.davas593.tddd78.jumpman.levels.Level;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class JumpmanPanel extends JPanel implements Runnable {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int STANDARDUNIT = 20;

    public static double GRAVITY = 10;

    public static final long NANOSECOND = 1000000000;

    public static boolean reachedFlag = false;
    public static boolean hitByEnemy = false;
    public static boolean powerUpActive = false;
    public static boolean bossHit = false;

    private Thread thread;
    private boolean running;
    private final int fps = 60;
    private final long frame_length = NANOSECOND/fps;

    public static int score;
    public static int powerUpColor = 0;
    private int powerUpCounter = 0;

    private Level level;

    private ArrayList<KeyStroke> pressed_keys;

    public JumpmanPanel(){
        initGame();
        System.out.println("game initialized");
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        requestFocus();
    }

    private void initGame(){
        level = new DummyLevel();
        thread = new Thread(this);

        if(DummyLevel.currentLevel == 1){
            score = 0;
        }

        setKeyBindings();

        running = true;
        thread.start();
    }


    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        final Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(Color.BLACK);
        g2d.fillRect(0,0, WIDTH, HEIGHT);

        level.draw(g2d);

        if(reachedFlag && DummyLevel.currentLevel == 3){
            g2d.setColor(Color.WHITE);
            g2d.drawString("Game completed!", 400, 200);

            g2d.drawString("Choose to play again in file menu", 400, 300);
        }

        if(hitByEnemy){
            g2d.setColor(Color.WHITE);
            g2d.drawString("Game over!", 400, 200);

            g2d.drawString("Choose to play again in file menu", 400, 300);
        }

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("default", Font.BOLD, 24));
        g2d.drawString(String.valueOf(score), 680, 50);

    }

    public void tick(long delta_time){
        level.tick(delta_time);
    }


    @Override
    public void run() {
        long currentTime;
        long deltaTime;
        long lastFrame = System.nanoTime();
        System.out.println("thread started");

        while(running && !reachedFlag && !hitByEnemy) {
            currentTime = System.nanoTime();
            deltaTime = currentTime - lastFrame;

            if (deltaTime >= frame_length) {
                lastFrame = currentTime;

                level.handleKeyPresses(pressed_keys);
                tick(deltaTime);
                this.repaint();
            }
        }

        if(reachedFlag) {
            if (DummyLevel.currentLevel != 3){
                reachedFlag = false;
                DummyLevel.currentLevel++;
                score += 1000;
                initGame();
            }else{
                this.repaint();
            }
        }
    }

    public void setKeyBindings() {
        pressed_keys = new ArrayList<KeyStroke>();
        final InputMap in = this.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW);
        final ActionMap act = this.getActionMap();

        in.put(KeyStroke.getKeyStroke("LEFT"), "pressLeft");
        in.put(KeyStroke.getKeyStroke("released LEFT"), "releaseLeft");
        act.put("pressLeft", new PressAction("LEFT"));
        act.put("releaseLeft", new ReleaseAction("LEFT"));

        in.put(KeyStroke.getKeyStroke("RIGHT"), "pressRight");
        in.put(KeyStroke.getKeyStroke("released RIGHT"), "releaseRight");
        act.put("pressRight", new PressAction("RIGHT"));
        act.put("releaseRight", new ReleaseAction("RIGHT"));

        in.put(KeyStroke.getKeyStroke("SPACE"), "pressSpace");
        in.put(KeyStroke.getKeyStroke("released SPACE"), "releaseSpace");
        act.put("pressSpace", new PressAction("SPACE"));
        act.put("releaseSpace", new ReleaseAction("SPACE"));

        in.put(KeyStroke.getKeyStroke("UP"), "pressUp");
        in.put(KeyStroke.getKeyStroke("released UP"), "releaseUp");
        act.put("pressUp", new PressAction("UP"));
        act.put("releaseUp", new ReleaseAction("UP"));
    }

    private class PressAction extends AbstractAction {
        KeyStroke key;

        @Override public void actionPerformed(final ActionEvent e){
            if (!pressed_keys.contains(key)) {
                pressed_keys.add(key);
            }
        }

        public PressAction(String keyString) {
            key = KeyStroke.getKeyStroke(keyString);
        }
    }

    private class ReleaseAction extends AbstractAction {
        KeyStroke key;

        @Override public void actionPerformed(final ActionEvent e){
            pressed_keys.remove(key);
        }

        public ReleaseAction(String keyString) {
            key = KeyStroke.getKeyStroke(keyString);
        }
    }

}
