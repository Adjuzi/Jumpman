package se.liu.adaan690.davas593.tddd78.jumpman;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JumpmanFrame extends JFrame {

    private JumpmanPanel jumpmanPanel;

    public JumpmanFrame(final String title){
        super(title);
        jumpmanPanel = new JumpmanPanel();
        setUpFrame();
        this.setVisible(true);
    }

    private void setUpFrame(){
        this.setContentPane(jumpmanPanel);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setLocationRelativeTo(null);

        final JMenuBar menuBar = new JMenuBar();
        final JMenu file = new JMenu("File");
        JMenuItem newGame = new JMenuItem("New Game");
        newGame.addActionListener(new NewGameListener());
        file.add(newGame);
        file.addSeparator();
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(new QuitListener());
        file.add(exit);
        menuBar.add(file);

        setJMenuBar(menuBar);
    }

    private class NewGameListener implements ActionListener {
        public void actionPerformed(ActionEvent e){
            int answer = JOptionPane.showConfirmDialog(null, "Start a new game?",
                    "New game?", JOptionPane.YES_NO_OPTION);
            if(answer == JOptionPane.YES_OPTION){
                dispose();
                Jumpman.main(null);
            }
        }
    }

    private class QuitListener implements ActionListener{
        public void actionPerformed(ActionEvent e){
            int answer = JOptionPane.showConfirmDialog(null, "Do you really want to quit?",
                    "Quit?", JOptionPane.YES_NO_OPTION);
            if(answer == JOptionPane.YES_OPTION){
                System.exit(0);
            }
        }
    }

}
