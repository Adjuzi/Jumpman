package se.liu.adaan690.davas593.tddd78.jumpman.levels;

import se.liu.adaan690.davas593.tddd78.jumpman.*;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.BottomCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.LeftCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.RightCollisionHandler;
import se.liu.adaan690.davas593.tddd78.jumpman.collisions.TopCollisionHandler;

import java.util.ArrayList;

public class LevelBuilds {
    private ArrayList<Ladder> ladders;
    private WinFlag winFlag1;
    private ArrayList<Platform> platforms;
    private ArrayList<Enemy> enemies;
    private ArrayList<PowerUp> powerUps;
    private Boss bossman;

    public LevelBuilds() {
        ladders = new ArrayList<Ladder>();
        platforms = new ArrayList<Platform>();
        enemies = new ArrayList<Enemy>();
        powerUps = new ArrayList<PowerUp>();
    }

    public void surroundings(int LevelNumber){
        if(LevelNumber == 1){
            Platform platform1 = Platform.createStandardPlatform(200, 500, 400);
            platform1.addCollisionHandler(new TopCollisionHandler(platform1));
            /*platform1.addCollisionHandler(new BottomCollisionHandler(platform1));
            platform1.addCollisionHandler(new LeftCollisionHandler(platform1));
            platform1.addCollisionHandler(new RightCollisionHandler(platform1));*/
            platforms.add(platform1);

            Platform platform2 = Platform.createStandardPlatform(0, 420, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform2));
            platforms.add(platform2);

            Platform platform3 = Platform.createStandardPlatform(640, 420, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform3));
            platforms.add(platform3);

            Platform platform4 = Platform.createStandardPlatform(0, 220, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform4));
            platforms.add(platform4);

            Platform platform5 = Platform.createStandardPlatform(640, 220, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform5));
            platforms.add(platform5);

            Platform platform6 = Platform.createStandardPlatform(200, 160, 400);
            platform1.addCollisionHandler(new TopCollisionHandler(platform6));
            platforms.add(platform6);


            Ladder ladder1 = new Ladder(300, JumpmanPanel.HEIGHT-JumpmanPanel.STANDARDUNIT*5, JumpmanPanel.STANDARDUNIT*3, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder1);
            Ladder ladder2 = new Ladder(60, 220, JumpmanPanel.STANDARDUNIT*10, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder2);
            Ladder ladder3 = new Ladder(700, 220, JumpmanPanel.STANDARDUNIT*10, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder3);

            winFlag1 = new WinFlag(380, 120, JumpmanPanel.STANDARDUNIT*2, JumpmanPanel.STANDARDUNIT);

            Enemy enemy1 = new Enemy( 40, 400);
            enemies.add(enemy1);
            Enemy enemy2 = new Enemy( 720, 400);
            enemy2.setVelX(-enemy2.getVelX());
            enemies.add(enemy2);

            PowerUp p1 = new PowerUp(400, 480);
            powerUps.add(p1);

        }else if(LevelNumber == 2){
            Platform platform1 = Platform.createStandardPlatform(200, 500, 400);
            platform1.addCollisionHandler(new TopCollisionHandler(platform1));
            platforms.add(platform1);

            Platform platform2 = Platform.createStandardPlatform(0, 420, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform2));
            platforms.add(platform2);

            Platform platform3 = Platform.createStandardPlatform(640, 420, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform3));
            platforms.add(platform3);

            Platform platform4 = Platform.createStandardPlatform(200, 200, 400);
            platform1.addCollisionHandler(new TopCollisionHandler(platform4));
            platforms.add(platform4);

            Platform wall1 = Platform.createWall(140, 420, 100);
            wall1.addCollisionHandler(new LeftCollisionHandler(wall1));
            wall1.addCollisionHandler(new RightCollisionHandler(wall1));
            wall1.addCollisionHandler(new TopCollisionHandler(wall1));
            wall1.addCollisionHandler(new BottomCollisionHandler(wall1));
            platforms.add(wall1);

            Ladder ladder1 = new Ladder(300, JumpmanPanel.HEIGHT-JumpmanPanel.STANDARDUNIT*5, JumpmanPanel.STANDARDUNIT*3, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder1);
            Ladder ladder2 = new Ladder(60, 220, JumpmanPanel.STANDARDUNIT*10, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder2);
            Ladder ladder3 = new Ladder(700, 220, JumpmanPanel.STANDARDUNIT*10, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder3);

            winFlag1 = new WinFlag(380, 160, JumpmanPanel.STANDARDUNIT*2, JumpmanPanel.STANDARDUNIT);
        }else if(LevelNumber == 3){
            Platform platform1 = Platform.createStandardPlatform(200, 500, 400);
            platform1.addCollisionHandler(new TopCollisionHandler(platform1));
            platforms.add(platform1);

            Platform platform2 = Platform.createStandardPlatform(0, 420, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform2));
            platforms.add(platform2);

            Platform platform3 = Platform.createStandardPlatform(640, 420, 160);
            platform1.addCollisionHandler(new TopCollisionHandler(platform3));
            platforms.add(platform3);

            Platform platform4 = Platform.createStandardPlatform(200, 350, 400);
            platform1.addCollisionHandler(new TopCollisionHandler(platform4));
            platforms.add(platform4);

            Platform wall1 = Platform.createWall(140, 420, 100);
            wall1.addCollisionHandler(new LeftCollisionHandler(wall1));
            wall1.addCollisionHandler(new RightCollisionHandler(wall1));
            wall1.addCollisionHandler(new TopCollisionHandler(wall1));
            wall1.addCollisionHandler(new BottomCollisionHandler(wall1));
            platforms.add(wall1);

            Ladder ladder1 = new Ladder(300, JumpmanPanel.HEIGHT-JumpmanPanel.STANDARDUNIT*5, JumpmanPanel.STANDARDUNIT*3, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder1);
            Ladder ladder2 = new Ladder(60, 220, JumpmanPanel.STANDARDUNIT*10, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder2);
            Ladder ladder3 = new Ladder(700, 220, JumpmanPanel.STANDARDUNIT*10, JumpmanPanel.STANDARDUNIT);
            ladders.add(ladder3);

            winFlag1 = new WinFlag(380, 310, JumpmanPanel.STANDARDUNIT*2, JumpmanPanel.STANDARDUNIT);

            bossman = new Boss( 300, 330);
        }

    }

    public ArrayList<Ladder> getLadders() {
        return ladders;
    }

    public WinFlag getWinFlag1() {
        return winFlag1;
    }

    public ArrayList<Platform> getPlatforms() {
        return platforms;
    }

    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }

    public ArrayList<PowerUp> getPowerUps() {
        return powerUps;
    }

    public Boss getBoss() {
        return bossman;
    }
}
