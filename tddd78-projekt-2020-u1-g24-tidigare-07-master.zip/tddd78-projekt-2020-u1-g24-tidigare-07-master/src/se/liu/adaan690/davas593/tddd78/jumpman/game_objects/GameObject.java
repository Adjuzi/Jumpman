package se.liu.adaan690.davas593.tddd78.jumpman.game_objects;

import se.liu.adaan690.davas593.tddd78.jumpman.JumpmanPanel;

import java.awt.*;

public abstract class GameObject
{
    protected double xPos;
    protected double yPos;
    protected int width = JumpmanPanel.STANDARD_UNIT;
    protected int height = JumpmanPanel.STANDARD_UNIT;
    protected Color color = Color.BLACK;

    protected GameObject(final int xPos, final int yPos, final Color color) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.color = color;
    }

    protected GameObject(final int xPos, final int yPos, final int width, final int height, final Color color) {
	this.xPos = xPos;
	this.yPos = yPos;
	this.width = width;
	this.height = height;
	this.color = color;
    }

    public double getXPos() {
	return xPos;
    }

    public int getIntXPos() {
	return (int) Math.round(xPos);
    }

    public void setXPos(final double xPos) {
	this.xPos = xPos;
    }

    public double getYPos() {
	return yPos;
    }

    public int getIntYPos() {
	return (int) Math.round(yPos);
    }

    public void setYPos(final double yPos) {
	this.yPos = yPos;
    }

    public int getWidth() {
	return width;
    }

    public int getHeight() {
	return height;
    }

    public Color getColor() {
	return color;
    }

    public void draw(Graphics g) {
	g.setColor(color);
	g.fillRect(getIntXPos(), getIntYPos(), width, height);
    }
}
